package school.cesar.poo.av2.agenda;

public class View {
	private ListaFrame gui;
	private AddFrame popup;

	public ListaFrame getGui() {
		return gui;
	}

	public void setGui(ListaFrame gui) {
		this.gui = gui;
	}

	public AddFrame getPopup() {
		return popup;
	}

	public void setPopup(AddFrame popup) {
		this.popup = popup;
	}
}