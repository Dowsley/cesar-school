A avaliação 2 consiste em implementar um pequeno aplicativo Java no estilo agenda de contatos.
A figura poo-av2.png apresenta um esboço de como deve ser a tela. 
Por se tratar de uma aplicação gráfica, recomenda-se o uso do Eclipse com o WindowBuilder conforme fizemos em sala.
Segue o arquivo Eclipse-Setup.pdf (já usado anteriormente) com o roteiro para instalação do WindowBuilder.
Lembrem-se de todos os conceitos vistos nas últimas aulas (encapsulamento, separação em componentes, correta estru
turação das classes básicas, ...), sua entrega será avaliada de acordo com a correta aplicação de todos os
conceitos vistos em sala de aula.
Seu JFrame principal deve ser exibido a partir da execução da classe schoo.ceaar.poo.av2.agenda.Agenda, já existe
um método main em branco, basta completá-lo referenciando o JFrame que você implementou.